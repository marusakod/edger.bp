

set -ex



$R -e "library('BPCells')"
if command -v macs3; then $R -e "testthat::test_package('BPCells', stop_on_failure=TRUE)"; fi
exit 0
